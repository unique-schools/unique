<?php
    $title = "UIS - About Us";
    $css = "about";
    include "php/nav.php";
?>

<main>
  <div class = "wrapper">
        <div id = "left">
		   <h1>What We Offer</h1>
		     <p>Far Far Away, behind the world mountains, Far from the the country nigeria
		         Far Far Away, behind the world mountains, Far from the the country nigeria
		        Far Far Away, behind the world mountains, Far from the the country nigeria
		         Far Far Away, behind the world mountains, Far from the the country nigeria</p>

        <div id="sub-group">
				   <div class="sub-left">
						<h2 class="img1"> Safety First</h2>
						   <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
						<h2 class="img2">Certified Teachers</h2>
						   <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
						<h2 class="img3">Creative Lesson</h2>
						   <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
					 </div>
					<div class="sub-right">
						<h2 class="img4">Regular Classes</h2>
						   <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
						<h2 class="img5">Sufficient Classrooms</h2>
						   <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
						<h2 class="img6" >Sport Facilities</h2>
						  <p>Far Far Away, behind the world mountains, Far from the the country nigeria</p>
					</div>
				</div>
		</div>
		<div id="right">

			<h1 class="up">Stay Motivated</h1>
			<p class="shift"><em>"Far Far Away, behind the world mountains, Far from the the country nigeria
		         Far Far Away, behind the world mountains, Far from the the country nigeria" --- Pluto</em></p>

		     <h1>Word of the Day</h1>
		     <p><strong>Jovial</strong></p>
		     <p>Far Far Away, behind the world mountains, Far from the the country nigeria
		         Far Far Away, behind the world mountains, Far from the the country nigeria</p>
		     <button>Read More</button>
		</div>
	</div>


</main>

<?php
    include "php/footer.php";
?>
