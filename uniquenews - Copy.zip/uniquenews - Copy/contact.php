<?php 
    $title = "UIS - Give us a shout out";
    $css = "contact";
    include "php/nav.php";
?>

<main></main>

<?php 
    include "php/footer.php";
?>