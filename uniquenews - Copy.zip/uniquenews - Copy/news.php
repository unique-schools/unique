<?php 
    $title = "UIS - News";
    $css = "news";
    include "php/nav.php";
?>

<main>
    <section class="news-head">
        <section class="news-left">
            <h1>What's Happening In Our School ?</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.</p>
        </section>  
        <button>Read On!</button>
    </section>
    
    <section class="headline">
        <h2>News Room</h2>
        <section class="headline-cont">
            <section class="headline-row">
                <section class="headline-col">
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                </section>
                <section class="headline-col">
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                    <section class="headline-col-post">
                        <img src="images/adult.jpg">
                        <article>
                            <h3>This is today's News</h3>
                            <p>Blah, blah, blah, today, this this and this happened. It is such a happy occasion for the school, yah.</p>
                            <ul>
                                <li><a href=""><em></em> Author</a></li>
                                <li><a href=""><em></em> Read More &rarr;</a></li>
                            </ul>
                        </article>
                    </section>
                </section>
            </section>
        </section>
    </section>
</main>

<?php 
    include "php/footer.php";
?>