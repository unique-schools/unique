<?php 
    $title = "UIS - welcome back person";
    $css = "profile";
    include "php/nav.php";
?>

<main></main>

<?php 
    include "php/footer.php";
?>