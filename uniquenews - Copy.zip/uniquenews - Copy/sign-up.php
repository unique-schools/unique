<?php 
    $title = "UIS - register";
    $css = "form";
    include "php/nav.php";
?>

<main></main>

<?php 
    include "php/footer.php";
?>